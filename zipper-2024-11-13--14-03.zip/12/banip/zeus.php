<?php
// zeus.php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define the path to the "blocked.txt" file
$blockedFile = __DIR__ . '/blocked.txt';

// Check if the file exists before attempting to read it
if (file_exists($blockedFile)) {
    // Read the list of blocked IP addresses from "blocked.txt" into an array
    $blocked_ips = file($blockedFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Get the visitor's IP address
    $ip = $_SERVER['REMOTE_ADDR'];

    // Check if the visitor's IP matches any of the blocked IPs
    if (in_array($ip, $blocked_ips)) {
        // Redirect to "https://google.com" if the IP is blocked
        header("Location: https://google.com");
        exit; // Terminate script execution
    }

    // Continue with your regular page logic here...
} else {
    // Handle the case where "blocked.txt" is not found
    die('Error: "blocked.txt" file not found.');
}
?>
