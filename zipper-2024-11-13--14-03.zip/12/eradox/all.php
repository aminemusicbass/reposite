<?php
	include('anti4.php');
	include('anti5.php');
	include('anti6.php');
?>